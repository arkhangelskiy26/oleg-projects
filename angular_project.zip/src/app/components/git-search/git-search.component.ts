import { Component, OnInit, AfterViewInit, ViewChild, ElementRef } from '@angular/core';
import { GitItem } from '../git-item/git-item.component';
import { Observable, fromEvent, of } from 'rxjs';
import { ajax } from 'rxjs/ajax';
import { map, filter, debounceTime, distinctUntilChanged, switchMap, tap } from 'rxjs/operators';
import { BookmarkService } from '../../services/bookmark.service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-git-search',
  templateUrl: './git-search.component.html',
  styleUrls: ['./git-search.component.scss']
})
export class GitSearchComponent implements OnInit, AfterViewInit {

  @ViewChild('searchInput', {static: false}) searchInput: ElementRef;

  constructor(
    private http: HttpClient,
    private bookmarkService: BookmarkService
    ) { }

  inputStream$: Observable<GitItem[]>;
  ngOnInit() {
  }

  ngAfterViewInit() {
    this.inputStream$ = fromEvent(this.searchInput.nativeElement, 'input').pipe(
      map((e: KeyboardEvent) => (e.target as HTMLInputElement).value),
      // filter(text => text.length > 2),
      debounceTime(200),
      distinctUntilChanged(),
      switchMap((text) => {
        return this.http.get<any>(`/testservice/mytest/query?keyword=${text}`).pipe(
          map((resp:any) => {
            const res = [];
            resp.forEach((item:any) => {
              res.push({
                id: item.html_url,
                repoName: item.name,
                url: item.html_url,
                ownerName: item.owner.login,
				language: item.language
              });
            });
            this.bookmarkService.updateItems(res);
            return res;
          })
        );
      }),
    );
  }
}