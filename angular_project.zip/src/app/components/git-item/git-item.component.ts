import { Component, OnInit, Input } from '@angular/core';
import { BookmarkService } from '../../services/bookmark.service';

export interface GitItem {
  id: string;
  repoName: string;
  url: string;
  ownerName: string;
  language: string;
  bookmarked?: boolean;
}

@Component({
  selector: 'app-git-item',
  templateUrl: './git-item.component.html',
  styleUrls: ['./git-item.component.scss']
})
export class GitItemComponent implements OnInit {

  constructor(private bookmarkService: BookmarkService) { }

  ngOnInit() {
  }

  @Input() item: GitItem;

  toggleBookmark() {
    this.item.bookmarked = !this.item.bookmarked;
    this.bookmarkService.toggleBookmark(this.item.id);
  }
}