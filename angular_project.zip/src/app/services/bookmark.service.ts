import { Injectable } from '@angular/core';
import { GitItem } from '../components/git-item/git-item.component';

@Injectable()
export class BookmarkService {

  bookmarks: {[key: string]: any} = {};

  constructor() {
    var bookmarks = localStorage.getItem('bookmarks');
    if (bookmarks) {
      this.bookmarks = JSON.parse(bookmarks);
    }
  }

  toggleBookmark(id: string) {
    if (this.bookmarks[id]) {
      delete this.bookmarks[id];
    } else {
      this.bookmarks[id] = true;
    }

    localStorage.setItem('bookmarks', JSON.stringify(this.bookmarks));
  }

  updateItems(items: GitItem[]) {
    items.forEach((item: GitItem) => {
      item.bookmarked = !!this.bookmarks[item.id];
    });
  }
}