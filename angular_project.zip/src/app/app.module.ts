import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { GitSearchComponent } from './components/git-search/git-search.component';
import { GitItemComponent } from './components/git-item/git-item.component';
import { BookmarkService } from './services/bookmark.service';

@NgModule({
  imports:      [ BrowserModule, FormsModule, HttpClientModule ],
  declarations: [ AppComponent, GitSearchComponent, GitItemComponent ],
  bootstrap:    [ AppComponent ],
  providers: [ BookmarkService ]
})
export class AppModule { }
