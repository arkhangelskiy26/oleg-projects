module.exports = {
  context: [
    "/testservice"
  ],
  target: "http://localhost:8080",
  secure: false
};