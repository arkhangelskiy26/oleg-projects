package test.search;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;

public class GitSearchHtppClient {
    // one instance, reuse
    private final CloseableHttpClient httpClient = HttpClients.createDefault();

    public static void main(String[] args) throws Exception {

    	GitSearchHtppClient obj = new GitSearchHtppClient();

        try {
            System.out.println("Testing 1 - Send Http GET request");
            obj.sendGet("virgo");
        } finally {
            obj.close();
        }
    }

    private void close() throws IOException {
        httpClient.close();
    }

    public String sendGet(String keyWord) throws Exception {

        HttpGet request = new HttpGet("https://api.github.com/search/repositories?q=" + 
        							   keyWord +"+language:php+language:javascript");
        
        ObjectMapper mapper = new ObjectMapper();
        String result = "";
        Item[] items = null;

        try (CloseableHttpResponse response = httpClient.execute(request)) {

            // Get HttpResponse Status
            System.out.println(response.getStatusLine().toString());

            HttpEntity entity = response.getEntity();
            Header headers = entity.getContentType();
            System.out.println(headers);
            
            if (entity != null) {
                // return it as a String
                String strResponce = EntityUtils.toString(entity);
                
                ResponceObject responseObject = mapper.readValue(strResponce, ResponceObject.class);
                items = responseObject.getItems();
                System.out.println("Found repos: " + items.length);
                System.out.println("URL = " + items[0].getHtml_url() + 
                		"; LogName = " + items[0].getOwner().getLogin() + "; Language = " + items[0].getLanguage());
                System.out.println("URL = " + items[1].getHtml_url() + 
                		"; LogName = " + items[1].getOwner().getLogin() + "; Language = " + items[0].getLanguage());
                result = mapper.writeValueAsString(items);
            }
        }
        return result;
    }
}
